<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank You</title>
</head>
<body>
    <h2>Thank You for Registering!</h2>
    <p>Your registration has been successfully submitted.</p>
</body>
</html>
