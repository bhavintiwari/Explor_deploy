<?php
$backgroundImage = "https://globalgrasshopper.com/wp-content/uploads/2011/01/Mumbai-India-scaled.jpg";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ExplorMor-Home</title>
  <link rel="stylesheet" href="style.css">
  <link rel="icon" href="Img/EM logo.jpg" type="image/x-icon">
  <style>
    .hero {
      background: url('<?php echo $backgroundImage; ?>') no-repeat center center/cover;
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      text-align: center;
      color: #fff;
    }
    
    /* Modal Styles */
    .modal {
      display: none;
      position: fixed;
      z-index: 1;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background-color: rgba(0, 0, 0, 0.4);
      padding-top: 60px;
    }
    
    .modal-content {
      background-color: #fefefe;
      margin: 5% auto;
      padding: 20px;
      border: 1px solid #888;
      width: 80%;
      max-width: 600px;
    }
    
    .close {
      color: #aaa;
      float: right;
      font-size: 28px;
      font-weight: bold;
    }

    .close:hover,
    .close:focus {
      color: black;
      text-decoration: none;
      cursor: pointer;
    }
    
    footer {
      text-align: center;
      margin-top: 20px;
    }
  </style>
</head>
<body>
  <header>
    <nav>
      <div class="logo">
        <h1>ExplorMor</h1>
      </div>
      <ul class="nav-links">
        <li><a href="home.php" class="active">Home</a></li>
        <li><a href="destination.php">Destinations</a></li>
        <li><a href="submit_contact.php">Contact-Us</a></li>
      </ul>
    </nav>
  </header>
 
  <section class="hero">
    <div class="hero-content">
      <h1>ExplorMor Travels</h1>
      <p>Choose your dream destination and travel with us.</p>
      <a href="booktour.php" class="btn">Book Your Tour</a>
    </div>
  </section>

  <div class="about-box">
    <h1>About Us</h1>
    <p>Welcome to ExplorMor, your ultimate travel partner for unforgettable journeys around the globe. 
      We specialize in providing personalized tours, guided excursions, and seamless travel experiences. Whether you're
      looking for a relaxing beach holiday or an adventurous trekking expedition, we’ve got you covered.</p>

    <h2>Why Choose Us?</h2>
    <ul>
      <li><strong>Expert Guides:</strong> Our experienced and knowledgeable guides ensure you get the best out of every destination.</li>
      <li><strong>Tailored Packages:</strong> We offer custom travel packages to suit your personal preferences and budget.</li>
      <li><strong>24/7 Support:</strong> Our customer support team is available round the clock to assist with any travel queries or emergencies.</li>
      <li><strong>Wide Range of Destinations:</strong> From hidden gems to popular tourist spots, we cover it all.</li>
      <li><strong>Sustainable Travel:</strong> We are committed to responsible tourism and minimizing our environmental impact.</li>
      <li><strong>Customer Satisfaction:</strong> Your satisfaction is our priority, and we go the extra mile to ensure a memorable trip.</li>
    </ul>
  </div>

  <!-- Footer Section -->
  <footer>
    <p>&copy; 2025 Travel with Us. All rights reserved. <a href="#" id="termsLink">Terms and Conditions</a></p>
  </footer>

  <!-- Modal for Terms and Conditions -->
  <div id="termsModal" class="modal">
    <div class="modal-content">
      <span class="close" id="closeModal">&times;</span>
      <h2>Terms and Conditions</h2>
      <p>Welcome to ExplorMor! By using our services, you agree to the following terms and conditions:</p>
      <ul>
        <li><strong>Booking Policy:</strong> All bookings must be made in advance and confirmed by our team.</li>
        <li><strong>Payment Terms:</strong> Payments should be made prior to the trip as per the agreed schedule.</li>
        <li><strong>Cancellation Policy:</strong> Cancellations made less than 24 hours before the scheduled trip may incur a fee.</li>
        <li><strong>Liability:</strong> ExplorMor is not responsible for any injuries or losses incurred during travel.</li>
        <li><strong>Refund Policy:</strong> Refunds will be processed according to the nature of the cancellation.</li>
      </ul>
      <p>By proceeding with the booking, you acknowledge that you have read, understood, and agreed to the terms above.</p>
    </div>
  </div>

  <!-- JavaScript for Modal -->
  <script>
    // Modal functionality
    const termsLink = document.getElementById("termsLink");
    const termsModal = document.getElementById("termsModal");
    const closeModal = document.getElementById("closeModal");

    termsLink.addEventListener("click", function() {
      termsModal.style.display = "block";
    });

    closeModal.addEventListener("click", function() {
      termsModal.style.display = "none";
    });

    window.onclick = function(event) {
      if (event.target == termsModal) {
        termsModal.style.display = "none";
      }
    };
  </script>
</body>
</html>
