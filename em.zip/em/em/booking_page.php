<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Form</title>
    <link rel="stylesheet" href="booking_page.css">
</head>
<body>
    <h2>Booking Form</h2>

    <!-- Booking form -->
    <form action="payments.php" method="POST">
        <label for="package_id">Package ID:</label><br>
        <input type="number" id="package_id" name="package_id" required><br><br>

        <label for="package_name">Package Name:</label><br>
        <input type="text" id="package_name" name="package_name" required><br><br>

        <label for="price">Price:</label><br>
        <input type="number" id="price" name="price" step="0.01" required><br><br>

        <label for="user_name">Your Name:</label><br>
        <input type="text" id="user_name" name="user_name" required><br><br>

        <label for="user_email">Your Email:</label><br>
        <input type="email" id="user_email" name="user_email" required><br><br>

        <label for="user_phone">Your Phone Number:</label><br>
        <input type="text" id="user_phone" name="user_phone" required><br><br>

        <label for="state_name">State:</label><br>
        <input type="text" id="state_name" name="state_name" required><br><br>

        <input type="submit" value="Submit Booking">
    </form>

    <!-- Display success or error messages -->
    <?php
    if (!empty($success_message)) {
        echo "<p class='success'>$success_message</p>";
    }
    if (!empty($error_message)) {
        echo "<p class='error'>$error_message</p>";
    }
    ?>
</body>
</html>
<?php
// Database connection settings and form processing
$servername = "localhost"; 
$username = "root";
$password = "";
$dbname = "explormor"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$package_id = $package_name = $price = $user_name = $user_email = $user_phone = $state_name = "";
$success_message = "";
$error_message = "";

// Process the form when it is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $package_id = $_POST['package_id'];
    $package_name = $_POST['package_name'];
    $price = $_POST['price'];
    $user_name = $_POST['user_name'];
    $user_email = $_POST['user_email'];
    $user_phone = $_POST['user_phone'];
    $state_name = $_POST['state_name'];

    // Get the current timestamp for booking_date
    $booking_date = date('Y-m-d H:i:s');

    // Prepare and bind the SQL query to insert data into bookings table
    $stmt = $conn->prepare("INSERT INTO bookings (package_id, package_name, price, user_name, user_email, user_phone, booking_date, s_id, state_name) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issdsssss", $package_id, $package_name, $price, $user_name, $user_email, $user_phone, $booking_date, 0, $state_name);

    // Execute the query and check if it's successful
    if ($stmt->execute()) {
        $success_message = "Booking successful! Your booking has been saved.";
        $booking_id = $stmt->insert_id;  // Get the last inserted booking_id
        // Display the link to go to payments.php
        echo "<p class='success'>$success_message</p>";
        echo "<a href='payments.php?booking_id=$booking_id&user_name=" . urlencode($user_name) . "&price=$price' class='button'>Go to Payment</a>";
    } else {
        $error_message = "Error: " . $stmt->error;
        echo "<p class='error'>$error_message</p>";
    }

    // Close the prepared statement
    $stmt->close();
}

// Close the database connection
$conn->close();
?>
