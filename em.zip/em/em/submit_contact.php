<?php
// Database connection settings
$servername = "localhost"; // Your database server (usually "localhost")
$username = "root"; // Your MySQL username (default for XAMPP is "root")
$password = ""; // Your MySQL password (default for XAMPP is empty)
$dbname = "explormor"; // Replace with your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$name = $email = $subject = $message = "";
$success_message = "";
$error_message = "";

// Process the form when it is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data and sanitize it
    $name = $_POST['name'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    // Get the current timestamp for created_at
    $created_at = date('Y-m-d H:i:s');

    // Prepare and bind the SQL query to insert data into contactus table
    $stmt = $conn->prepare("INSERT INTO contactus (name, email, subject, message, created_at) VALUES (?, ?, ?, ?, ?)");
    if ($stmt === false) {
        die('Prepare failed: ' . $conn->error);
    }

    $stmt->bind_param("sssss", $name, $email, $subject, $message, $created_at);

    // Execute the query and check if it's successful
    if ($stmt->execute()) {
        $success_message = "Thank you for contacting us! Your message has been received.";
    } else {
        $error_message = "Error: " . $stmt->error;
    }

    // Close the prepared statement
    $stmt->close();
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <link rel="stylesheet" href="contactus.css">
</head>
<body>
    <h2>Contact Us</h2>

    <form action="submit_contact.php" method="POST">
        <label for="name">Your Name:</label><br>
        <input type="text" id="name" name="name" required><br><br>

        <label for="email">Your Email:</label><br>
        <input type="email" id="email" name="email" required><br><br>

        <label for="subject">Subject:</label><br>
        <input type="text" id="subject" name="subject" required><br><br>

        <label for="message">Message:</label><br>
        <textarea id="message" name="message" rows="4" cols="50" required></textarea><br><br>

        <input type="submit" value="Send Message">
    </form>

    <?php
    // Display success or error message
    if (!empty($success_message)) {
        echo "<p class='success'>$success_message</p>";
    }
    if (!empty($error_message)) {
        echo "<p class='error'>$error_message</p>";
    }
    ?>
</body>
</html>
