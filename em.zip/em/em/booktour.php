<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tour Booking Request</title>
    <link rel="stylesheet" href="booktour.css">
</head>
<body>

<header>
    <nav>
        <div class="logo">
            <h1>ExplorMor</h1>
        </div>
        <ul class="nav-links">
            <li><a href="home.php">Home</a></li>
            <li><a href="destination.php">Destinations</a></li>
            <li><a href="submit_contact.php">Contact Us</a></li>
        </ul>
    </nav>
</header>

<section class="tour-request-form">
    <h2>Submit Your Tour Request</h2>
    <form action="submit_tour_request.php" method="POST">
        <div class="form-group">
            <label for="full_name">Full Name:</label>
            <input type="text" id="full_name" name="full_name" required>
        </div>

        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
        </div>

        <div class="form-group">
            <label for="phone_number">Phone Number:</label>
            <input type="text" id="phone_number" name="phone_number" required>
        </div>

        <div class="form-group">
            <label for="tour_destination">Tour Destination:</label>
            <input type="text" id="tour_destination" name="tour_destination" required>
        </div>

        <div class="form-group">
            <label for="tour_state_date">Tour Start Date:</label>
            <input type="date" id="tour_state_date" name="tour_state_date" required>
        </div>

        <div class="form-group">
            <label for="tour_end_date">Tour End Date:</label>
            <input type="date" id="tour_end_date" name="tour_end_date" required>
        </div>

        <div class="form-group">
            <label for="number_of_people">Number of People:</label>
            <input type="number" id="number_of_people" name="number_of_people" required>
        </div>

        <div class="form-group">
            <label for="tour_type">Tour Type:</label>
            <input type="text" id="tour_type" name="tour_type" required>
        </div>

        <div class="form-group">
            <label for="special_request">Special Requests:</label>
            <textarea id="special_request" name="special_request"></textarea>
        </div>

        <div class="form-group">
            <label for="budget">Budget:</label>
            <input type="number" id="budget" name="budget" required>
        </div>

        <button type="submit">Submit Request</button>
    </form>
</section>

<footer>
    <p>&copy; 2025 ExplorMor. All rights reserved.</p>
</footer>

</body>
</html>
