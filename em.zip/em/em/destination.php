<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Explore Destinations - ExplorMor</title>
    <link rel="stylesheet" href="styled.css">
</head>
<body>

<header>
    <nav>
        <div class="logo">
            <h1>ExplorMor</h1>
        </div>
        <ul class="nav-links">
            <li><a href="home.php">Home</a></li>
            <li><a href="destination.php" class="active">Destination</a></li>
            <li><a href="submit_contact.php">Contact Us</a></li>
        </ul>
    </nav>
</header>

<section class="destination-page">  
    <h2>Explore Our Destinations</h2>

    <div class="search-container">
        <form id="searchForm" action="search.php" method="GET">
            <input type="text" name="searchQuery" id="searchQuery" placeholder="Search for a state..." required>
            <button type="submit">Search</button>
        </form>
    </div>

    <div class="destination-grid" id="destination-grid">
    <?php
        // Database connection details
        $servername = "localhost";  // Change this to your database host if different
        $username = "root";         // Your MySQL username
        $password = "";             // Your MySQL password (empty for default on localhost)
        $dbname = "explormor";      // Replace with your database name

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // SQL query to fetch data from states table
        $sql = "SELECT * FROM states";
        $result = $conn->query($sql);

        // Check if there are rows to display
        if ($result->num_rows > 0) {
            // Output each row
            while($row = $result->fetch_assoc()) {
                // Ensure the image path is correct (update the src URL if necessary)
                $imageSrc = 'imgs/' . $row["state_image"];  // Assuming your images are in a folder called 'images' on the server
                
                echo '<div class="destination-card">';
                echo '<img src="' . $imageSrc . '" alt="' . $row["state_name"] . '">';
                echo '<h3>' . $row["state_name"] . '</h3>';
                echo '<p>' . $row["state_description"] . '</p>';
                // echo '<a href="package.php  ' . strtolower($row["state_name"]) . '.html" class="destination">View Packages</a>';
                // echo '<a href="package.php?state=' . urlencode($row["s_id"]) . '" class="destination">View Packages</a>';
                echo '<a href="package.php?s_id=' . $row["s_id"] . '" class="destination">View Packages</a>';



                echo '</div>';
            }
        } else {
            echo "0 results";
        }

        // Close connection
        $conn->close();
    ?>
    </div>
</section>

<footer>
    <p>&copy; 2025 Travel with Us. All rights reserved.</p>
</footer>

<script>
    function searchFunction() {
        var searchQuery = document.getElementById('searchQuery').value.toLowerCase();  // Get the search input and convert to lowercase
        var destinations = document.querySelectorAll('.destination-card');  // Get all destination elements

        // Loop through all destinations
        destinations.forEach(function(destination) {
            // Get the name of each destination
            var destinationName = destination.querySelector('h3').textContent.toLowerCase();

            // If the destination name contains the search query, show it, else hide it
            if (destinationName.includes(searchQuery)) {
                destination.style.display = 'block';  // Show the destination
            } else {
                destination.style.display = 'none';  // Hide the destination
            }
        });
    }

    // You could call this search function in your search form if you want to filter destinations
    document.getElementById('searchForm').addEventListener('submit', function(e) {
        e.preventDefault();  // Prevent the form from submitting
        searchFunction();  // Perform search
    });
</script>

</body>
</html>
